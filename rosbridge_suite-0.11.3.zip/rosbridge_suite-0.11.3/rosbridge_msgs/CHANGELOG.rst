^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rosbridge_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.11.3 (2019-08-07)
-------------------

0.11.2 (2019-07-08)
-------------------

0.11.1 (2019-05-08)
-------------------

0.11.0 (2019-03-29)
-------------------
* Additional client information websocket (`#393 <https://github.com/RobotWebTools/rosbridge_suite/issues/393>`_)
  * Add package rosbridge_msgs.
  * rosbridge_server: Publish additional information about connected clients.
  * rosbridge_server: Make ClientManager's add_client/remove_client methods thread safe.
  * rosbridge_server: Rm unnecessary publishing.
  * rosbridge_msgs: Cleanup/fix dependencies.
* Contributors: Hans-Joachim Krauch
